import java.awt.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;

/*
 *	Directions: 
 *				In the paint method Choose if you want to draw your paddle or 
 *				if you want to use an image to make a paddle.
 *				
 *				Finish the goLeft & goRight methods
 *
 *				Go to BreakOut and do Step 1.
 *				Then test it out in the runner.
 *				If all of the paddle works move on to Ball
 */
 
 
class Paddle extends Block
{
	private int speed; // a paddle has to have a speed to make it move
	
	public Paddle( int ex, int wy, int wd, int ht, int sp)
	{
		super(ex,wy,wd,ht);
		speed=sp;
		//write the code for the Paddle constructor
		//must have a super constructor call
	}
	public void goLeft()
	{
	  setX( getX() - speed*2 ); // because a paddle is a block it has the setX and getX methods
	  if(getX()<=0) {
		  setX(1);
	  }
	}
	public void goRight() {
		setX(getX() + speed * 2);
		if (getX() >= 1228) {
			setX(1228);
		}
	}
	public void goUp()
	{
		setY(getY() - speed*2);
		if(getY()>=1228) {
			setY(1228);
		}
	}
	public void goDown()
	{
		setY(getY() + speed*2);
		if(getY()<= 0) {
			setY(0);
		}
	}
	
	//overidde paint to draw your Paddle
	public void paint( Graphics window )
	{
		
		// drawing methods for Java: 
		// go to the Graphics Intro Folder

		window.setColor(Color.WHITE);

		window.fillRect(getX(), getY(), getW(), getH());
		window.drawRect(getX(), getY(), getW(), getH());
		

		//find and image for your paddle and put it here
    		Graphics2D g2 = (Graphics2D) window;
    		Image img1 = Toolkit.getDefaultToolkit().getImage("rocket.png"); //use .gif or .png, you can choose the image
    		g2.drawImage(img1, getX(), getY(), getW(), getH(), this);
    	
	}	
		
}